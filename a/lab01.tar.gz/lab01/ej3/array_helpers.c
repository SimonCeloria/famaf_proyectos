#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "array_helpers.h"

unsigned int array_from_file (int array[],
                             unsigned int max_size,
                             const char *filepath){
    FILE * fp;
    fp = fopen(filepath, "r");
    
    if (fp == NULL){
        printf("Error filepath.\n");
        exit(EXIT_FAILURE);
    }

    unsigned int size;
    int result = fscanf(fp, "%u", &size); 
    if(result != 1){
        printf("Error in format file.\n");
        exit(EXIT_FAILURE);
    }
    if(size > max_size){
        printf("Allowed maxsize: %d.\n",max_size);
        exit(EXIT_FAILURE);
    }

    unsigned int i = 0;
    while (i < size){
        result = fscanf(fp, "%d", &array[i]);
        if (result != 1){
            printf("Error in format file.\n");
            exit(EXIT_FAILURE);
        }
        ++i;
    }

    fclose(fp);
    return size;
}

void array_dump(int a[], unsigned int length) {
    
    printf("[");
    
    for(unsigned int i = 0u; i < length; ++i){
        printf("%d", a[i]);
        if(i < length - 1) {
            printf(", ");
        }
    }
    printf("]\n");
}