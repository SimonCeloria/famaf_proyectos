#include <assert.h>
#include "builtin.h"
#include <stddef.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>

const char* internal_commands[] = {"cd", "help", "exit"};
const int NUM_INTERNAL_COMMANDS = 3;

bool builtin_is_internal(scommand cmd){
    assert(cmd != NULL);
    const char* command_name = scommand_front(cmd);
    for (size_t i = 0; i < NUM_INTERNAL_COMMANDS ;  i++)
    {
        if (strcmp(command_name,internal_commands[i]) == 0)
        {
            return true;
        }
    }
    return false;
}

bool builtin_alone(pipeline p){
    assert(p != NULL);
    if (pipeline_length(p) == 1)
    {
        return (builtin_is_internal(pipeline_front(p)));
    }

    return false;
}

void builtin_run_cd(scommand cmd){
    const char* new_directory = scommand_front(cmd);
    if (new_directory != NULL)
    {
        if (chdir(new_directory) == 0)
        {
            printf("Directory changed to %s\n", new_directory);
        }
        else {
            fprintf(stderr, "cd");
        }
        
    }
    else 
    {
        fprintf(stderr, "Incorrect use of cd. Usage: cd <directory>\n");
    }
    
}

void builtin_run_help(scommand cmd){
    fprintf(stdout, "Welcome to the custom command interpreter.\n"
                    "Available commands:\n"
                    "cd - Change the current directory.\n"
                    "help - Display this help.\n"
                    "exit - Exit the interpreter.\n");
}

void builtin_run_exit(scommand cmd){
    exit(0);
}

void builtin_run(scommand cmd){
    assert(builtin_is_internal(cmd));
    const char* command_name = scommand_front(cmd);
    if (strcmp(command_name, "cd") == 0) 
    {
        builtin_run_cd(cmd);
    } 
    else if (strcmp(command_name, "help") == 0) 
    {
        builtin_run_help(cmd);
    } 
    else if (strcmp(command_name, "exit") == 0) 
    {
        builtin_run_exit(cmd);
    }
}
