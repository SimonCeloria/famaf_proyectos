#ifndef TEST_PIPELINE_H
#define TEST_PIPELINE_H

#include <check.h>

Suite *pipeline_suite (void);

void pipeline_memory_test (void);

#endif
