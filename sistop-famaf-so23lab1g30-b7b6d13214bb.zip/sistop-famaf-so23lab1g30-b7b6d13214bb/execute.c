// Librerias estandar

#include <stdlib.h>
#include <stdbool.h>

// Librearias internas

#include "builtin.h"
#include "execute.h"
#include "command.h"

void execute_pipeline(pipeline apipe) //Recibo un pipeline, no un scommand por lo que tengo que convertir el pipeline en scommand si quiero usar funciones de builtin
{

    if (builtin_is_internal) // Si el comanando es scommand/interno lo ejecuto
    {
        scommnad new_scommand = pipeline_front(apipe); //Extraigo el comando de la pipeline
        builtin_run(new_scommand); // Ejecuto el comando
    }
    else if (builtin_alone) // Si la pipeline posee un solo elemento y corresponde a un comando interno/scommand
    {
        scommnad new_scommand = pipeline_front(apipe); //Extraigo el comando de la pipeline
        builtin_run(new_scommand); // Ejecuto el comando
    }
    else
    { // Si es una pipeline tengo que ejecutarlo creando un hijo con fork() y esperar que termine con wait()
        int rc = fork();

        if (rc == 0)
        {
            // Reemplazo el hijo
            printf("Hola soy el hijo deberia imprimirme primero\n");



            exit(0); //Termino el hijo
        }
        else
        {
            printf("Funciono piola espero al hijo\n");
            cpid = wait(NULL); // El padre espera al hijo
            printf("Listo el pibe termino\n");
        }
    }
}