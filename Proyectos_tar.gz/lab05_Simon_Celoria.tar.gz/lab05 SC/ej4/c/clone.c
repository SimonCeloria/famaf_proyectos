#include <stdlib.h>
#include <stdio.h>
#include <string.h>

char *string_clone(const char *str, size_t length) {
    char *output = malloc((length + 1)*sizeof(char));
    for (size_t i=0; i<length; i++) {
        output[i] = str[i];
    }
    output[length] = '\0';
    return output;
}


int main(void) {
    char *original=""
         "______ time ago in a galaxy far, far away...\n\n\n"
         "         _______..___________.     ___      .______             \n"
         "        /       ||           |    /   \\     |   _  \\          \n"
         "       |   (----``---|  |----`   /  ^  \\    |  |_)  |          \n"
         "        \\   \\        |  |       /  /_\\  \\   |      /        \n"
         "    .----)   |       |  |      /  _____  \\  |  |\\  \\----.    \n"
         "    |_______/        |__|     /__/     \\__\\ | _| `._____|     \n"
         "                                                                \n"
         "____    __    ____      ___      .______           _______.     \n"
         "\\   \\  /  \\  /   /     /   \\     |   _  \\         /       |\n"
         " \\   \\/    \\/   /     /  ^  \\    |  |_)  |       |   (----` \n"
         "  \\            /     /  /_\\  \\   |      /         \\   \\    \n"
         "   \\    /\\    /     /  _____  \\  |  |\\  \\----..----)   |   \n"
         "    \\__/  \\__/     /__/     \\__\\ | _| `._____||_______/     \n"
         "\n\n\n"
         "                     Episode IV \n\n"
         "                     A NEW HOPE \n\n"
         "                     It is a period of civil war. Rebel\n"
         "spaceships, striking from a hidden base, have won their\n"
         "first victory against the evil Galactic Empire. During the\n"
         "battle, Rebel spies managed to steal secret plans to the\n"
         "Empire’s ultimate weapon, the DEATH STAR, an armored space\n"
         "station with enough power to destroy an entire planet.\n"
         "Pursued by the Empire’s sinister agents, Princess Leia\n"
         "races home aboard her starship, custodian of the stolen\n"
         "plans that can save her people and restore freedom to the\n"
         "galaxy...\n";
    char *copy=NULL;
    copy = string_clone(original, strlen(original));
    printf("Original: %s\n", original);
    copy[0] = 'A';
    copy[1] = ' ';
    copy[2] = 'l';
    copy[3] = 'o';
    copy[4] = 'n';
    copy[5] = 'g';
    printf("Copia   : %s\n", copy);
    free(copy);


    return EXIT_SUCCESS;
}


/*
Usar gdb para averiguar el valor que toma el parámetro length cuando se llama a
string_clone() -> Originalmente usa sizeof(original)/sizeof(char) - 1 que calcula:
El tamaño de original sizeof(original) = 8 y luego sizeof(char) = 1 y le resta 1, es decir 8/1 - 1 = 7
lo cual es muy facil de ver utilizando 2 printf de la siguiente forma:
printf("%ld\n",sizeof(original));
printf("%ld\n",sizeof(char));
O bien:
printf("%ld\n",sizeof(original)/sizeof(char) - 1);
printf("%ld\n",sizeof(char));
Tambien podria utilizar gdb y hacer un break en la linea 44 y utilizar p sizeof(original)/sizeof(char) - 1)

Los problemas encontrados son dos:
El segundo argumento de string_clone, pasandole algo invalido y luego en la funcion string_clone
retorna un puntero al cual no alojamos en memoria dinamica por lo que al salir de la funcion ese puntero
que tiene el string copiado desaparece, lo cual hace imposible conservar el string copiado.
Esto se puede observar utilizando valgrind ya que nos avisara de que a partir de la linea 49 estoy tratando de escribir caracteres 
en lugares de memoria a los que no tengo accseso
*/
