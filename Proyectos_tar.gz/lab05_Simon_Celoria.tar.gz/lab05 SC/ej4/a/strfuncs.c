#include <stdlib.h>
#include <stdio.h>

#include "strfuncs.h"

size_t string_length(const char *str){
    int length = 0;

    while (*str != '\0') {
        length++;
        str++;
    }
    return length;
}

char *string_filter(const char *str, char c){
    int length = string_length(str); //Calculo el largo del str para saber cuanta memoria alojar
    char *filtered_str = (char *)malloc((length + 1) * sizeof(char)); //Casteo el puntero generico *void devuelto por malloc a tipo *char que es el deseado.
                                        // Lenghh + 1 es para saber cuantos caracteres como maximo tiene el string y lo multiplico por la cantidad de bits necesarios por cada char
    if (filtered_str == NULL) {
        return NULL;  //En caso de fallar en la asignacion apunto a NULL
    }

    int i, j = 0;
    for (i = 0; i < length; i++) {
        if (str[i] != c) { //Si el elemento en la posicion i es distinto de c entonces lo guardo en string nuevo filtrado
            filtered_str[j] = str[i]; 
            j++;
        }
    }

    filtered_str[i] = '\0';
    return filtered_str;
}
