#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

#define ARRAY_SIZE 4

typedef struct  {
    bool is_upperbound;
    bool is_lowerbound;
    bool exists;
    unsigned int where;
}bound_data;

bound_data check_bound(int value, int arr[], unsigned int length) {
     bound_data res;
	 unsigned int i = 0;
     res.is_upperbound = true;
	 res.is_lowerbound = true;
	 res.exists = false;
	
	while(i<length){
		if (value > arr[i]){
			res.is_lowerbound = res.is_lowerbound && false;
		}
		if (value < arr[i]){
			res.is_upperbound = res.is_upperbound && false;
		}
		if (value == arr[i]){
			res.exists = true;
			res.where = i;
		}
		i++;
	}
	
    return res;
}

void pedirArreglo(int a[], int legth){
	int i = 0;

	printf("Ingrese los valores para el arreglo.\n");
	while(i < legth){
		printf("Ingrese entero en la posicion %d: \n", i);
		scanf("%d", &a[i]);
		i++;
	}
}
	

int main(void) {
    int a[ARRAY_SIZE];
	pedirArreglo(a, ARRAY_SIZE);
	
	int value;
	printf("Ingrese valor entero: \n");
	scanf("%d", &value);
	
     bound_data result = check_bound(value, a, ARRAY_SIZE);

	if (result.is_upperbound){
		printf("El valor es cota superior de este arreglo.");
		if (result.exists){
			printf("Ademas es el maximo,");
		}
	}
	if (result.is_lowerbound){
		printf("El valor es cota inferior de este arreglo.");
		if (result.exists){
			printf("Ademas es el minimo,");
		}
	}
	if (result.exists){
		printf("se encuentra en la posicion:%d\.n", result.where);
	}
   
    return EXIT_SUCCESS;
}

