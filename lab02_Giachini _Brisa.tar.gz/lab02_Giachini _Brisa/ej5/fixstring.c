#include <stdbool.h>
#include <assert.h>

#include "fixstring.h"

unsigned int fstring_length(fixstring s) {
    unsigned int count = 0u;
    for(unsigned int i = 0u; i<FIXSTRING_MAX && (s[i] != '\0');++i){
        count = count + 1;
    }
    return count;
}

bool fstring_eq(fixstring s1, fixstring s2) {
    bool result = true;
    unsigned int i = 0u;
    unsigned int length = fstring_length(s1);
    if (length == fstring_length(s2)){
        while (i<length && result){
            if (s1[i] != s2[i]){
                result = false;
            }
            i = i + 1u;
        }
    }
    else{
        result = false;
    }
    return result;
}

bool fstring_less_eq(fixstring s1, fixstring s2) {
    bool result = true;
    unsigned int i = 0u;
    unsigned int length1 = fstring_length(s1);
    unsigned int length2 = fstring_length(s2);

    while(i<length1 && result){
        if (s1[i]>s2[i] && (s2[i] != '\0' || length1 > length2)){
            result = false;
        } else if (s1[i] == s2[i]){
            result = true;
        } else{
            return result;
        }
        i = i + 1u;
    }
    return result;
}

void fstring_set(fixstring s1, const fixstring s2) {
    int i=0;
    while (i<FIXSTRING_MAX && s2[i]!='\0') {
        s1[i] = s2[i];
        i++;
    }
    s1[i] = '\0';
}

void fstring_swap(fixstring s1,  fixstring s2) {
    fixstring aux;
    fstring_set(aux,s1);
    fstring_set(s1,s2);
    fstring_set(s2,aux);
}